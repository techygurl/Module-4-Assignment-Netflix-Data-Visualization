# In R image
library(png)
library(grid)
img <- readPNG("C:\\Users\\Varnosafety INT\\Downloads\\topgenres.png")
grid::grid.raster(img)