#!/usr/bin/env python
# coding: utf-8

#  # Perform data preparation by unzipping the dataset and renaming it to "Netflix_shows_movies."
# 
# 

# In[12]:


import os

oldest_path = r"C:\Users\Varnosafety INT\Downloads\netflix_data.csv"
newest_path = r"C:\Users\Varnosafety INT\Downloads\Netflix_shows_movies.csv"

os.rename(old_path, new_path)


# In[18]:


import pandas as pd
import matplotlib 
import shapely
import json
import numpy as np
import numpy as np  # Numerical operations
import seaborn as sns  # Statistical data visualization
import matplotlib.pyplot as plt  # Plotting and visualization
import geopandas as gpd #for coordinates
import mapclassify
from IPython.display import display, HTML  # Displaying HTML output in Jupyter notebooks
import warnings  # Suppress warnings
from colorama import Fore, Style  # Colored terminal text
import plotly.express as px


# In[19]:


import pandas as pd

df = pd.read_csv(r"C:\Users\Varnosafety INT\Downloads\Netflix_shows_movies.csv")
df.head()


# # Address missing values in the dataset through data cleaning.

# In[20]:


df = df.drop_duplicates()
df


# In[33]:


# how many missing values are in each column
df.isnull().sum()


# In[22]:


df_cleaned = df.dropna()
df_cleaned


# # Conduct data exploration, including generating data descriptions and performing statistical analysis.

# In[30]:


df_cleaned.describe()


# In[24]:


df_cleaned = df


# # Create visualizations to represent the most watched genres and the distribution of ratings using Python libraries (Seaborn, Pyplot, and Matplotlib).

# In[29]:


# Split and flatten the genres
genres = df['listed_in'].dropna().str.split(', ')
flat_genres = genres.explode()

# Count the top 10 genres
top_genres = flat_genres.value_counts().head(10)

# Plot
plt.figure(figsize=(10, 6))
sns.barplot(x=top_genres.values, y=top_genres.index, palette='magma')
plt.title('Top 10 Most Common Genres on Netflix')
plt.xlabel('Number of Shows/Movies')
plt.ylabel('Genre')
plt.tight_layout()
plt.show()


# In[28]:


plt.figure(figsize=(10, 6))
sns.countplot(data=df, y='rating', order=df['rating'].value_counts().index, palette='coolwarm')
plt.title('Distribution of Content Ratings on Netflix')
plt.xlabel('Count')
plt.ylabel('Rating')
plt.tight_layout()
plt.show()

